package com.pknu.my01.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Mycontroller {
    @GetMapping("/")
    public String mainPage(Model model) {
        model.addAttribute("hello", "만나서 아주 반갑습니다. 스프링부트 시작합니다.");
        model.addAttribute("name", "김기윤");
        model.addAttribute("age", 26);
        model.addAttribute("gender", "남");
        return "index.html";

    }

    @GetMapping("/ex01")
    public String ex01(Model model) {
        model.addAttribute("hello", "만나서 아주 반갑습니다. 스프링부트 시작합니다.");
        model.addAttribute("name", "이성훈");
        model.addAttribute("age", 26);
        model.addAttribute("gender", "남");
        return "ex01.html";

    }

}
