package com.pknu.my01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class My01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
