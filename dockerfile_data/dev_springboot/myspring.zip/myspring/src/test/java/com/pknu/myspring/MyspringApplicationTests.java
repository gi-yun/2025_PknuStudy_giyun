package com.pknu.myspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
